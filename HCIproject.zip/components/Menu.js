import * as React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize } from "../GlobalStyles";

const Menu = ({ onClose }) => {
  const navigation = useNavigation();

  return (
    <View style={styles.menu}>
      <Pressable
        style={[styles.aboutUs, styles.homePosition]}
        onPress={() => navigation.navigate("AboutUs")}
      >
        <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>{`About Us
`}</Text>
      </Pressable>
      <Pressable
        style={[styles.exercise, styles.homePosition]}
        onPress={() => navigation.navigate("Exercises")}
      >
        <Text style={styles.aboutUs1Typo}>Exercise</Text>
      </Pressable>
      <Pressable
        style={[styles.contact, styles.homePosition]}
        onPress={() => navigation.navigate("Contact")}
      >
        <Text style={styles.aboutUs1Typo}>Contact</Text>
      </Pressable>
      <Pressable
        style={[styles.home, styles.homePosition]}
        onPress={() => navigation.navigate("Home")}
      >
        <Text style={styles.aboutUs1Typo}>Home</Text>
      </Pressable>
      <Image
        style={[styles.menuChild, styles.homePosition]}
        contentFit="cover"
        source={require("../assets/group-24.png")}
      />
      <View style={[styles.menuItem, styles.menuLayout]} />
      <View style={[styles.menuInner, styles.menuLayout]} />
      <View style={[styles.lineView, styles.menuLayout]} />
    </View>
  );
};

const styles = StyleSheet.create({
  homePosition: {
    top: 31,
    position: "absolute",
  },
  aboutUs1Typo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.graduateRegular,
    fontSize: FontSize.size_sm,
  },
  menuLayout: {
    height: 21,
    width: 1,
    borderRightWidth: 1,
    borderColor: "#000",
    borderStyle: "solid",
    top: 29,
    position: "absolute",
  },
  aboutUs1: {
    width: 82,
    height: 18,
  },
  aboutUs: {
    left: 151,
  },
  exercise: {
    left: 66,
  },
  contact: {
    left: 239,
  },
  home: {
    left: 10,
  },
  menuChild: {
    left: 335,
    width: 16,
    height: 15,
  },
  menuItem: {
    left: 59,
  },
  menuInner: {
    left: 230,
  },
  lineView: {
    left: 142,
  },
  menu: {
    backgroundColor: Color.paleturquoise,
    width: 360,
    height: 77,
    overflow: "hidden",
    maxWidth: "100%",
    maxHeight: "100%",
  },
});

export default Menu;
