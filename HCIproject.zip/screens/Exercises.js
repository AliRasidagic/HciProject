import React, { useState, useCallback } from "react";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  Linking,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const Exercises = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.exercises}>
        <Text style={styles.chooseYourGoal}>Choose Your Goal!</Text>
        <View style={[styles.rectangleParent, styles.groupChildLayout]}>
          <View style={[styles.groupChild, styles.groupChildLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <View style={styles.groupPosition}>
          <View style={[styles.groupItem, styles.pngwing1Position]} />
          <View style={[styles.groupInner, styles.groupPosition]} />
          <Pressable
            style={styles.logo}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={styles.search}>Search...</Text>
        </View>
        <Pressable
          style={[styles.buildMuscleParent, styles.parentPosition]}
          onPress={() => navigation.navigate("Description")}
        >
          <Image
            style={[styles.buildMuscleIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/build-muscle.png")}
          />
          <Text style={[styles.buildMuscle, styles.buildMuscleTypo]}>
            Build Muscle
          </Text>
        </Pressable>
        <Pressable
          style={[styles.loseWeightParent, styles.parentPosition]}
          onPress={() => navigation.navigate("Description")}
        >
          <Image
            style={[styles.loseWeightIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/lose-weight.png")}
          />
          <Text style={[styles.buildMuscle, styles.buildMuscleTypo]}>
            Lose Weight
          </Text>
        </Pressable>
        <Pressable
          style={[styles.maintainBodyweightParent, styles.maintainLayout]}
          onPress={() => navigation.navigate("Description")}
        >
          <Image
            style={[styles.maintainBodyweightIcon, styles.maintainLayout]}
            contentFit="cover"
            source={require("../assets/maintain-bodyweight.png")}
          />
          <Text style={[styles.maintainBodyweight, styles.buildMuscleTypo]}>
            Maintain Bodyweight
          </Text>
        </Pressable>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
  },
  twitter1Layout: {
    height: 15,
    width: 15,
    top: 12,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupPosition: {
    height: 33,
    top: 0,
    width: 360,
    left: 0,
    position: "absolute",
  },
  parentPosition: {
    left: 100,
    width: 161,
    position: "absolute",
  },
  iconPosition: {
    width: 150,
    left: 5,
    position: "absolute",
  },
  buildMuscleTypo: {
    height: 24,
    fontFamily: FontFamily.graduateRegular,
    fontSize: FontSize.size_xl,
    top: 0,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  maintainLayout: {
    width: 266,
    position: "absolute",
  },
  chooseYourGoal: {
    bottom: 646,
    left: 61,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
    width: 237,
    transform: [
      {
        rotate: "0.35deg",
      },
    ],
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  rectangleParent: {
    top: 761,
  },
  groupItem: {
    left: 200,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
    width: 124,
  },
  groupInner: {
    backgroundColor: Color.gray_200,
  },
  logo: {
    top: 9,
    width: 120,
    left: 5,
    height: 15,
    position: "absolute",
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    fontSize: FontSize.size_xs,
    color: Color.gray_100,
    textAlign: "left",
    width: 50,
    height: 13,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  buildMuscleIcon: {
    height: 190,
    top: 12,
  },
  buildMuscle: {
    width: 161,
    left: 0,
  },
  buildMuscleParent: {
    top: 337,
    height: 202,
    width: 161,
  },
  loseWeightIcon: {
    height: 150,
    top: 0,
  },
  loseWeightParent: {
    top: 202,
    height: 150,
    width: 161,
  },
  maintainBodyweightIcon: {
    top: 24,
    height: 150,
    left: 0,
  },
  maintainBodyweight: {
    left: 8,
    width: 251,
  },
  maintainBodyweightParent: {
    top: 545,
    left: 47,
    height: 174,
  },
  exercises: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default Exercises;
