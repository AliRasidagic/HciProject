import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const StartingPage = () => {
  return (
    <View style={styles.startingPage}>
      <View style={[styles.rectangleParent, styles.rectangleLayout]}>
        <View style={[styles.frameChild, styles.frameLayout]} />
        <Text style={styles.register}>Register</Text>
      </View>
      <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
        <View style={[styles.frameItem, styles.frameLayout]} />
        <Text style={[styles.logIn, styles.logInClr]}>Log In</Text>
      </View>
      <Image
        style={styles.logoIcon}
        contentFit="cover"
        source={require("../assets/logo1.png")}
      />
      <Text style={[styles.all4sportLlc, styles.logInClr]}>
        © 2023, All4Sport, LLC.
      </Text>
      <Text style={[styles.welcome, styles.logInClr]}>Welcome!</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleLayout: {
    height: 53,
    width: 250,
    left: 55,
    position: "absolute",
  },
  frameLayout: {
    borderRadius: Border.br_xl,
    left: 0,
    top: 0,
    height: 53,
    width: 250,
    position: "absolute",
  },
  logInClr: {
    color: Color.black,
    position: "absolute",
  },
  frameChild: {
    backgroundColor: Color.midnightblue_200,
  },
  register: {
    top: 16,
    left: 92,
    color: Color.white,
    width: 67,
    height: 21,
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleParent: {
    top: 336,
  },
  frameItem: {
    backgroundColor: Color.white,
  },
  logIn: {
    top: 15,
    width: 53,
    height: 22,
    left: 99,
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_xl,
  },
  rectangleGroup: {
    top: 412,
  },
  logoIcon: {
    top: 60,
    left: 30,
    width: 300,
    height: 38,
    position: "absolute",
  },
  all4sportLlc: {
    top: 776,
    left: 109,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    width: 142,
    height: 11,
    fontFamily: FontFamily.frescaRegular,
  },
  welcome: {
    top: 272,
    fontSize: 30,
    fontFamily: FontFamily.graduateRegular,
    width: 162,
    height: 41,
    left: 99,
    color: Color.black,
    textAlign: "left",
  },
  startingPage: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default StartingPage;
