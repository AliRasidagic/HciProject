import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Linking,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const Medium = () => {
  const navigation = useNavigation();
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.medium}>
        <View style={[styles.mediumChild, styles.mediumLayout]} />
        <View style={[styles.mediumItem, styles.mediumLayout]} />
        <Text style={[styles.dumbellBenchPress, styles.pressFlexBox]}>
          Dumbell Bench Press
        </Text>
        <Text style={[styles.calfRaises, styles.calfRaisesPosition]}>
          Calf Raises
        </Text>
        <View style={[styles.mediumInner, styles.mediumChildLayout]} />
        <Text
          style={[styles.hammerCurls, styles.iconPosition1]}
        >{`Hammer Curls `}</Text>
        <View style={[styles.rectangleView, styles.mediumChildLayout]} />
        <Text style={[styles.tricepPushdown, styles.iconPosition1]}>
          Tricep Pushdown
        </Text>
        <View style={[styles.mediumChild1, styles.mediumChildLayout]} />
        <Text style={[styles.barbellMilitaryPress, styles.iconPosition1]}>
          Barbell Military Press
        </Text>
        <View style={[styles.mediumChild2, styles.mediumChildLayout]} />
        <Text style={[styles.latPulldown, styles.calfRaisesPosition]}>
          Lat Pulldown
        </Text>
        <View style={[styles.mediumChild3, styles.mediumChildLayout]} />
        <Text style={[styles.legExtensions, styles.pressFlexBox]}>
          Leg Extensions
        </Text>
        <Text style={[styles.medium1, styles.pressFlexBox]}>Medium</Text>
        <Pressable
          style={[styles.rectangleParent, styles.rectangleLayout]}
          onPress={() =>
            Linking.openURL("file:///C:/Users/PC/Downloads/medium1.pdf")
          }
        >
          <View style={[styles.groupChild, styles.groupPosition1]} />
          <Text style={[styles.downloadPlan, styles.searchTypo]}>
            Download Plan!
          </Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleGroup, styles.rectangleLayout]}
          onPress={() => navigation.navigate("WorkoutPlans")}
        >
          <View style={[styles.groupItem, styles.groupPosition1]} />
          <Text style={[styles.backToChoose, styles.searchTypo]}>
            Back to Choose Plans
          </Text>
        </Pressable>
        <Text
          style={[styles.suitedForPeople, styles.pressTypo]}
        >{`Suited for people who have access to a gym. This plan 
will result in more overall muscle development.   `}</Text>
        <View style={[styles.rectangleContainer, styles.groupInnerLayout]}>
          <View style={[styles.groupInner, styles.groupInnerLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <View style={styles.groupPosition}>
          <View style={[styles.groupChild1, styles.pngwing1Position]} />
          <View style={[styles.groupChild2, styles.groupPosition]} />
          <Pressable
            style={[styles.logo, styles.logoLayout]}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.searchTypo]}>Search...</Text>
        </View>
        <Text
          style={[styles.performTheDumbbell, styles.difficultyPosition]}
        >{`Perform the dumbbell bench press  by lying flat on a bench. Grab a pair of dumbbells and hold them on your hips. While engaging your core and glutes, lift the dumbbell above your chest. Squeeze your shoulder blades as you lower them again until your upper and lower arms 
form a 90-degree angle. `}</Text>
        <Text
          style={[styles.legExtensionsAre, styles.areTypo]}
        >{`Leg extensions are done on a leg extension machine.
You sit on a machine with a weighted pad on top of
your legs. Then use the quads to repeatedly extend 
your knees and lift your lower legs.  `}</Text>
        <Text style={[styles.theLatPulldown, styles.theLatPulldownPosition]}>
          The lat pulldown machine is used to target the back muscles. It is
          performed seated, facing towards the machine, where you pull a long
          bar attached to the cable, towards your chest adn then slowly extend
          your arms back to starting position.
        </Text>
        <Text style={[styles.aMilitaryPress, styles.aMilitaryPressPosition]}>
          A military press, also known as an overhead press is a barbell
          strength exercise that works mostly the shoulders and the triceps and
          traps. It is performed by lifting the bar overhead until elbows are
          locked. Remaining stable slowly lower the barbell back to starting
          position.
        </Text>
        <Text
          style={[styles.aTricepsPushdown, styles.difficultyEasyPosition]}
        >{`A triceps pushdown is a an isolation exercise. It is performed by standing in front a pulley machine with your feet shoulder width apart. Grab hold of the cable attachment on the pulley machine. This attachment can be fitted with a rope or a straight bar. Fully extend your arms and come up slow toward 90 degrees. `}</Text>
        <Text
          style={[styles.hammerCurlIs, styles.areTypo]}
        >{`Hammer curl is a variation of a dumbbell curl but its done with a neutral grip. It targets the long head of the biceps and is a very good exercise to build big biceps. `}</Text>
        <Text
          style={[styles.theyArePerformed, styles.areTypo]}
        >{`They are performed by standing tall with your feet hip-width apart. Lift your body by pushing into the fronts of your feet, activating your calf muscles as you stand on your tiptoes. Return to a regular stance and repeat  `}</Text>
        <Image
          style={[styles.rectangleIcon, styles.iconPosition1]}
          contentFit="cover"
          source={require("../assets/rectangle-12.png")}
        />
        <Image
          style={[styles.standingdumbbellbicepshammeIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/standingdumbbellbicepshammercurls-1.png")}
        />
        <Image
          style={styles.exerciseIcon}
          contentFit="cover"
          source={require("../assets/exercise7.png")}
        />
        <Image
          style={styles.exerciseIcon1}
          contentFit="cover"
          source={require("../assets/exercise8.png")}
        />
        <Image
          style={[styles.exerciseIcon2, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/exercise9.png")}
        />
        <Image
          style={styles.exerciseIcon3}
          contentFit="cover"
          source={require("../assets/exercise10.png")}
        />
        <Image
          style={styles.exerciseIcon4}
          contentFit="cover"
          source={require("../assets/exercise11.png")}
        />
        <Image
          style={[styles.exerciseIcon5, styles.iconPosition1]}
          contentFit="cover"
          source={require("../assets/exercise12.png")}
        />
        <Image
          style={[styles.exerciseIcon6, styles.calfRaisesPosition]}
          contentFit="cover"
          source={require("../assets/exercise13.png")}
        />
        <Text style={[styles.difficultyMedium, styles.theLatPulldownPosition]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyMedium1, styles.aMilitaryPressPosition]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyMedium2, styles.difficultyPosition]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyEasy, styles.difficultyEasyPosition]}>
          Difficulty: Easy
        </Text>
        <Text style={[styles.difficultyMedium3, styles.areTypo]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyMedium4, styles.areTypo]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyMedium5, styles.difficultyPosition]}>
          Difficulty: Medium
        </Text>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  mediumLayout: {
    height: 107,
    width: 300,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  pressFlexBox: {
    textAlign: "center",
    color: Color.black,
  },
  calfRaisesPosition: {
    left: 34,
    position: "absolute",
  },
  mediumChildLayout: {
    left: 30,
    height: 107,
    width: 300,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  iconPosition1: {
    left: 36,
    position: "absolute",
  },
  rectangleLayout: {
    height: 23,
    width: 111,
    left: 223,
    position: "absolute",
  },
  groupPosition1: {
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
    height: 23,
    width: 111,
    position: "absolute",
  },
  searchTypo: {
    height: 13,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  pressTypo: {
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  groupInnerLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  logoLayout: {
    height: 15,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupPosition: {
    height: 33,
    width: 360,
    left: 0,
    top: 0,
    position: "absolute",
  },
  difficultyPosition: {
    left: 94,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  areTypo: {
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  theLatPulldownPosition: {
    left: 106,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  aMilitaryPressPosition: {
    left: 123,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  difficultyEasyPosition: {
    left: 88,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  iconPosition: {
    left: 39,
    position: "absolute",
  },
  mediumChild: {
    top: 993,
    left: 32,
  },
  mediumItem: {
    left: 28,
    top: 227,
  },
  dumbellBenchPress: {
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    left: 33,
    textAlign: "center",
    position: "absolute",
    top: 227,
  },
  calfRaises: {
    top: 998,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  mediumInner: {
    top: 866,
  },
  hammerCurls: {
    top: 870,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  rectangleView: {
    top: 740,
  },
  tricepPushdown: {
    top: 742,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  mediumChild1: {
    top: 606,
  },
  barbellMilitaryPress: {
    top: 609,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  mediumChild2: {
    top: 480,
  },
  latPulldown: {
    top: 483,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
  },
  mediumChild3: {
    top: 350,
  },
  legExtensions: {
    top: 352,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    left: 33,
    textAlign: "center",
    position: "absolute",
  },
  medium1: {
    top: 85,
    left: 143,
    fontSize: FontSize.size_6xl,
    fontFamily: FontFamily.jockeyOneRegular,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
  },
  downloadPlan: {
    color: Color.white,
    width: 104,
    left: 4,
    top: 5,
    height: 13,
    fontSize: FontSize.size_xs,
    textAlign: "center",
  },
  rectangleParent: {
    top: 1138,
  },
  groupItem: {
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  backToChoose: {
    width: 104,
    left: 4,
    top: 5,
    height: 13,
    fontSize: FontSize.size_xs,
    textAlign: "center",
    color: Color.black,
  },
  rectangleGroup: {
    top: 1167,
  },
  suitedForPeople: {
    marginLeft: -152,
    top: 132,
    left: "50%",
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  groupInner: {
    backgroundColor: Color.gray_200,
    top: 0,
    width: 360,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  twitter1: {
    left: 336,
    width: 15,
    height: 15,
    top: 12,
  },
  instagram1: {
    left: 286,
    width: 15,
    height: 15,
    top: 12,
  },
  facebook1: {
    left: 311,
    width: 15,
    height: 15,
    top: 12,
  },
  rectangleContainer: {
    top: 1203,
  },
  groupChild1: {
    left: 200,
    width: 124,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  groupChild2: {
    backgroundColor: Color.gray_200,
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    color: Color.gray_100,
    width: 50,
    textAlign: "left",
    height: 13,
    fontSize: FontSize.size_xs,
  },
  performTheDumbbell: {
    width: 234,
    height: 69,
    textAlign: "justify",
    top: 248,
  },
  legExtensionsAre: {
    top: 368,
    left: 119,
    textAlign: "justify",
  },
  theLatPulldown: {
    top: 499,
    width: 215,
    textAlign: "justify",
  },
  aMilitaryPress: {
    top: 625,
    width: 198,
    height: 93,
    textAlign: "justify",
  },
  aTricepsPushdown: {
    top: 761,
    width: 236,
    textAlign: "justify",
  },
  hammerCurlIs: {
    top: 889,
    left: 97,
    width: 227,
    textAlign: "justify",
  },
  theyArePerformed: {
    top: 1015,
    left: 82,
    width: 242,
    height: 49,
    textAlign: "justify",
  },
  rectangleIcon: {
    top: 1026,
    width: 43,
    height: 43,
    borderRadius: Border.br_3xs,
    left: 36,
  },
  standingdumbbellbicepshammeIcon: {
    top: 894,
    width: 49,
    height: 52,
  },
  exerciseIcon: {
    top: 1224,
    left: -260,
    width: 19,
    height: 18,
    position: "absolute",
  },
  exerciseIcon1: {
    top: 404,
    left: -119,
    width: 27,
    height: 50,
    position: "absolute",
  },
  exerciseIcon2: {
    top: 766,
    width: 45,
    height: 59,
  },
  exerciseIcon3: {
    top: 502,
    left: 37,
    width: 63,
    height: 63,
    position: "absolute",
  },
  exerciseIcon4: {
    top: 639,
    left: 42,
    width: 46,
    height: 55,
    position: "absolute",
  },
  exerciseIcon5: {
    top: 379,
    width: 65,
    height: 67,
  },
  exerciseIcon6: {
    width: 56,
    height: 60,
    top: 248,
  },
  difficultyMedium: {
    top: 572,
    textAlign: "left",
  },
  difficultyMedium1: {
    top: 701,
    textAlign: "left",
  },
  difficultyMedium2: {
    top: 957,
    textAlign: "left",
  },
  difficultyEasy: {
    top: 836,
    textAlign: "left",
  },
  difficultyMedium3: {
    top: 1086,
    left: 81,
    textAlign: "left",
  },
  difficultyMedium4: {
    top: 439,
    left: 117,
    textAlign: "left",
  },
  difficultyMedium5: {
    top: 322,
    textAlign: "left",
  },
  medium: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 1242,
    overflow: "hidden",
    width: "100%",
  },
});

export default Medium;
