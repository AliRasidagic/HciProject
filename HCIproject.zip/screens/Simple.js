import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Linking,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Simple = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.simple}>
        <View style={[styles.simpleChild, styles.simpleChildLayout]} />
        <View style={[styles.simpleItem, styles.simpleChildLayout]} />
        <View style={[styles.simpleInner, styles.simpleChildLayout]} />
        <Text
          style={[styles.aBurpeeIs, styles.difficultyTypo]}
        >{`A burpee is essentially a two-part exercise; a push-up  followed by a leap in the air. Doing several burpees in a row will be exhausting but it will be worth it  because they offer a challenge that improves endurance, strength and boosting your cardio. `}</Text>
        <Image
          style={[styles.exerciseIcon, styles.exerciseIconPosition1]}
          contentFit="cover"
          source={require("../assets/exercise14.png")}
        />
        <Text
          style={[styles.itInvolvesStepping, styles.difficultyMedium1Position]}
        >{`It involves stepping forward, lowering your body towards the ground and returning back to the starting position. In  the beginning of the exercise your muscles have to control the impact of your foots landing. `}</Text>
        <View style={[styles.rectangleView, styles.simpleChildLayout]} />
        <View style={styles.simpleChild1} />
        <View style={[styles.simpleChild2, styles.burpeesPosition]} />
        <Text style={styles.simple1}>Simple</Text>
        <Text style={[styles.aSimplePlan, styles.plankTypo]}>
          A simple plan which consists of straightforward exercises which anyone
          can do that at home and are not time consuming
        </Text>
        <Text style={[styles.squats, styles.squatsTypo]}>Squats</Text>
        <Text style={[styles.diamondPushup, styles.logoLayout]}>
          Diamond Pushup
        </Text>
        <Text style={[styles.pushup, styles.squatsTypo]}>Pushup</Text>
        <Text style={[styles.plank, styles.plankPosition]}>Plank</Text>
        <Text style={[styles.lunges, styles.plankPosition]}>Lunges</Text>
        <Text style={[styles.burpees, styles.plankTypo]}>Burpees</Text>
        <Pressable
          style={[styles.rectangleParent, styles.rectangleLayout]}
          onPress={() =>
            Linking.openURL("file:///C:/Users/PC/Downloads/easy1.pdf")
          }
        >
          <View style={[styles.groupChild, styles.groupPosition]} />
          <Text style={[styles.downloadPlan, styles.searchLayout]}>
            Download Plan!
          </Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleGroup, styles.rectangleLayout]}
          onPress={() => navigation.navigate("WorkoutPlans")}
        >
          <View style={[styles.groupItem, styles.groupPosition]} />
          <Text style={[styles.backToChoose, styles.searchLayout]}>
            Back to Choose Plans
          </Text>
        </Pressable>
        <Image
          style={styles.exerciseIcon1}
          contentFit="cover"
          source={require("../assets/exercise15.png")}
        />
        <Text
          style={[styles.squatsAreDone, styles.areTypo]}
        >{`Squats are done by moving the hips back and bending the knees and hips to lower the torso and accompanying then returning to the upright position.
`}</Text>
        <Text
          style={[styles.pushUpsAre, styles.areTypo]}
        >{`Push ups are an exercise in which a person keeping a prone position with the palms hand down under the shoulders, the balls of the feet on the ground and the back straight, pushes the body and lets it down by an alternate straightening and bending of the arms. 
`}</Text>
        <Image
          style={[styles.exerciseIcon2, styles.exerciseIconPosition]}
          contentFit="cover"
          source={require("../assets/exercise16.png")}
        />
        <Image
          style={[styles.exerciseIcon3, styles.exerciseIconPosition]}
          contentFit="cover"
          source={require("../assets/exercise17.png")}
        />
        <View style={[styles.rectangleContainer, styles.groupChild1Layout]}>
          <View style={[styles.groupInner, styles.pngwing1Position]} />
          <View style={[styles.groupChild1, styles.groupChildBg]} />
          <Pressable
            style={[styles.logo, styles.logoLayout]}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.searchLayout]}>Search...</Text>
        </View>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={[styles.groupChild2, styles.groupLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <Text
          style={[styles.diamondPushUpsAre, styles.difficultyEasy2Position]}
        >{`Diamond push-ups are a variation a standard push up but they are more focused on the triceps but still  contribute to chest and shoulder development. They are executed by having your hands in a narrow grip. `}</Text>
        <Text
          style={[styles.pressYourHands, styles.difficultyTypo]}
        >{`Press your hands and knees to the floor with  your back in a neutral position and wrists aligned directly under your shoulders. Gaze about one foot in front of you. Your nose should point toward the floor and the back of your neck should be parallel to the ceiling.   `}</Text>
        <Image
          style={[styles.exerciseIcon4, styles.plankPosition]}
          contentFit="cover"
          source={require("../assets/exercise18.png")}
        />
        <Image
          style={[styles.exerciseIcon5, styles.exerciseIconPosition1]}
          contentFit="cover"
          source={require("../assets/exercise19.png")}
        />
        <Text style={[styles.difficultyEasy, styles.searchLayout]}>
          Difficulty: Easy
        </Text>
        <Text style={[styles.difficultyEasy1, styles.difficultyTypo]}>
          Difficulty: Easy
        </Text>
        <Text style={[styles.difficultyEasy2, styles.difficultyEasy2Position]}>
          Difficulty: Easy
        </Text>
        <Text style={[styles.difficultyMedium, styles.difficultyTypo]}>
          Difficulty: Medium
        </Text>
        <Text
          style={[styles.difficultyMedium1, styles.difficultyMedium1Position]}
        >
          Difficulty: Medium
        </Text>
        <Text
          style={[styles.difficultyMedium2, styles.difficultyTypo]}
        >{`Difficulty: Medium `}</Text>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  simpleChildLayout: {
    height: 107,
    width: 300,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  difficultyTypo: {
    fontFamily: FontFamily.frescaRegular,
    color: Color.black,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  exerciseIconPosition1: {
    left: 34,
    position: "absolute",
  },
  difficultyMedium1Position: {
    left: 118,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  burpeesPosition: {
    left: 33,
    position: "absolute",
  },
  plankTypo: {
    fontSize: FontSize.size_sm,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  squatsTypo: {
    left: 38,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  logoLayout: {
    height: 15,
    position: "absolute",
  },
  plankPosition: {
    left: 36,
    position: "absolute",
  },
  rectangleLayout: {
    height: 23,
    width: 111,
    left: 219,
    position: "absolute",
  },
  groupPosition: {
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
    height: 23,
    width: 111,
    position: "absolute",
  },
  searchLayout: {
    height: 13,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  areTypo: {
    height: 59,
    width: 216,
    textAlign: "justify",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_3xs,
    left: 111,
    position: "absolute",
  },
  exerciseIconPosition: {
    left: 17,
    width: 100,
    position: "absolute",
  },
  groupChild1Layout: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupChildBg: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  groupLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_3xs,
  },
  twitter1Layout: {
    width: 15,
    top: 12,
    height: 15,
    position: "absolute",
  },
  difficultyEasy2Position: {
    left: 114,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  simpleChild: {
    top: 849,
    left: 30,
    position: "absolute",
  },
  simpleItem: {
    top: 725,
    left: 30,
    position: "absolute",
  },
  simpleInner: {
    top: 220,
    left: 30,
    position: "absolute",
  },
  aBurpeeIs: {
    top: 865,
    width: 215,
    transform: [
      {
        rotate: "-0.3deg",
      },
    ],
    textAlign: "justify",
    color: Color.black,
    left: 111,
    fontFamily: FontFamily.frescaRegular,
  },
  exerciseIcon: {
    top: 741,
    width: 66,
    height: 77,
  },
  itInvolvesStepping: {
    top: 740,
    width: 205,
    height: 72,
    textAlign: "justify",
  },
  rectangleView: {
    top: 480,
    left: 30,
    position: "absolute",
  },
  simpleChild1: {
    marginTop: 41.5,
    marginLeft: -147,
    top: "50%",
    left: "50%",
    width: 294,
    height: 102,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  simpleChild2: {
    top: 350,
    height: 107,
    width: 300,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  simple1: {
    top: 85,
    left: 149,
    fontSize: FontSize.size_6xl,
    fontFamily: FontFamily.jockeyOneRegular,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  aSimplePlan: {
    top: 137,
    left: 35,
    width: 292,
    height: 49,
    textAlign: "justify",
    position: "absolute",
  },
  squats: {
    top: 354,
  },
  diamondPushup: {
    top: 486,
    width: 101,
    fontSize: FontSize.size_sm,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    left: 30,
  },
  pushup: {
    top: 223,
  },
  plank: {
    top: 612,
    fontSize: FontSize.size_sm,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
  },
  lunges: {
    top: 728,
    fontSize: FontSize.size_sm,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
  },
  burpees: {
    top: 853,
    textAlign: "center",
    left: 33,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
  },
  downloadPlan: {
    color: Color.white,
    width: 104,
    left: 4,
    top: 5,
    height: 13,
    fontSize: FontSize.size_xs,
    textAlign: "center",
  },
  rectangleParent: {
    top: 1000,
  },
  groupItem: {
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  backToChoose: {
    width: 104,
    left: 4,
    top: 5,
    height: 13,
    fontSize: FontSize.size_xs,
    textAlign: "center",
    color: Color.black,
  },
  rectangleGroup: {
    top: 1029,
  },
  exerciseIcon1: {
    top: 511,
    left: 26,
    height: 57,
    width: 100,
    position: "absolute",
  },
  squatsAreDone: {
    top: 369,
  },
  pushUpsAre: {
    top: 230,
  },
  exerciseIcon2: {
    top: 248,
    height: 72,
  },
  exerciseIcon3: {
    top: 379,
    height: 56,
  },
  groupInner: {
    left: 200,
    width: 124,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  groupChild1: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    color: Color.gray_100,
    width: 50,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    height: 13,
  },
  rectangleContainer: {
    top: 0,
    width: 360,
  },
  groupChild2: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  groupView: {
    top: 1084,
  },
  diamondPushUpsAre: {
    top: 502,
    height: 52,
    width: 216,
    left: 114,
    textAlign: "justify",
  },
  pressYourHands: {
    top: 610,
    left: 132,
    width: 190,
    height: 81,
    textAlign: "justify",
    color: Color.black,
  },
  exerciseIcon4: {
    top: 620,
    width: 89,
    height: 67,
  },
  exerciseIcon5: {
    top: 881,
    width: 76,
    height: 43,
  },
  difficultyEasy: {
    top: 300,
    width: 62,
    textAlign: "justify",
    color: Color.black,
    height: 13,
    fontSize: FontSize.size_3xs,
    left: 111,
  },
  difficultyEasy1: {
    top: 435,
    textAlign: "left",
    color: Color.black,
    left: 111,
    fontFamily: FontFamily.frescaRegular,
  },
  difficultyEasy2: {
    top: 568,
    textAlign: "left",
  },
  difficultyMedium: {
    top: 942,
    textAlign: "left",
    color: Color.black,
    left: 111,
    fontFamily: FontFamily.frescaRegular,
  },
  difficultyMedium1: {
    top: 817,
    textAlign: "left",
  },
  difficultyMedium2: {
    top: 687,
    left: 131,
    textAlign: "left",
    color: Color.black,
  },
  simple: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 1125,
    overflow: "hidden",
    width: "100%",
  },
});

export default Simple;
