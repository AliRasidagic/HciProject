import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const LogIn = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.logIn}>
      <View style={[styles.logInChild, styles.logLayout]} />
      <View style={[styles.logInItem, styles.logLayout]} />
      <Text style={[styles.password, styles.eMailTypo]}>Password</Text>
      <Text style={[styles.rememberMe, styles.rememberMeClr]}>Remember me</Text>
      <Pressable
        style={styles.forgotPassword}
        onPress={() => navigation.navigate("ChangePassword")}
      >
        <Text style={[styles.forgotPassword1, styles.cancel1Typo]}>
          Forgot password?
        </Text>
      </Pressable>
      <Text style={[styles.eMail, styles.eMailTypo]}>E-mail</Text>
      <Pressable
        style={styles.cancel}
        onPress={() => navigation.navigate("StartingPage")}
      >
        <Text style={[styles.cancel1, styles.cancel1Typo]}>Cancel</Text>
      </Pressable>
      <Pressable
        style={[styles.rectangleParent, styles.groupChildLayout]}
        onPress={() => navigation.navigate("Home")}
      >
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.logIn1, styles.logIn1Typo]}>Log In</Text>
      </Pressable>
      <Image
        style={[styles.logoIcon, styles.logoIconLayout]}
        contentFit="cover"
        source={require("../assets/logo1.png")}
      />
      <Image
        style={[styles.logoIcon1, styles.logoIconLayout]}
        contentFit="cover"
        source={require("../assets/logo1.png")}
      />
      <Text style={[styles.all4sportLlc, styles.rememberMeClr]}>
        © 2023, All4Sport, LLC.
      </Text>
      <View style={[styles.toggle, styles.toggleLayout]}>
        <Image
          style={[styles.baseSwitchIcon, styles.toggleLayout]}
          contentFit="cover"
          source={require("../assets/baseswitch-icon.png")}
        />
      </View>
      <Image
        style={styles.eyeIcon}
        contentFit="cover"
        source={require("../assets/eye.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  logLayout: {
    height: 51,
    width: 250,
    backgroundColor: Color.white,
    borderRadius: Border.br_xl,
    left: 55,
    position: "absolute",
  },
  eMailTypo: {
    height: 18,
    color: Color.gray_100,
    width: 200,
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_xl,
    left: 70,
    position: "absolute",
  },
  rememberMeClr: {
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  cancel1Typo: {
    textDecoration: "underline",
    height: 18,
    textAlign: "left",
    color: Color.gray_100,
    fontFamily: FontFamily.frescaRegular,
  },
  groupChildLayout: {
    height: 55,
    width: 250,
    position: "absolute",
  },
  logIn1Typo: {
    textAlign: "left",
    fontSize: FontSize.size_xl,
  },
  logoIconLayout: {
    height: 38,
    width: 300,
    left: 30,
    position: "absolute",
  },
  toggleLayout: {
    height: 20,
    overflow: "hidden",
  },
  logInChild: {
    top: 400,
  },
  logInItem: {
    top: 337,
  },
  password: {
    top: 417,
  },
  rememberMe: {
    top: 469,
    width: 120,
    height: 21,
    textAlign: "left",
    fontSize: FontSize.size_xl,
    color: Color.black,
    left: 70,
  },
  forgotPassword1: {
    fontSize: FontSize.size_sm,
    width: 200,
    textDecoration: "underline",
  },
  forgotPassword: {
    top: 502,
    left: 70,
    position: "absolute",
  },
  eMail: {
    top: 354,
  },
  cancel1: {
    fontSize: FontSize.size_base,
    width: 41,
  },
  cancel: {
    left: 158,
    top: 727,
    position: "absolute",
  },
  groupChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
    height: 55,
  },
  logIn1: {
    top: 16,
    left: 96,
    color: Color.white,
    width: 55,
    height: 22,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "left",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleParent: {
    top: 662,
    height: 55,
    left: 55,
  },
  logoIcon: {
    top: 61,
  },
  logoIcon1: {
    top: 60,
  },
  all4sportLlc: {
    top: 775,
    left: 109,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    width: 142,
    height: 11,
  },
  baseSwitchIcon: {
    borderRadius: Border.br_980xl,
    width: 21,
  },
  toggle: {
    top: 470,
    left: 192,
    borderRadius: Border.br_xs,
    backgroundColor: Color.midnightblue_100,
    width: 36,
    flexDirection: "row",
    padding: Padding.p_11xs,
    alignItems: "center",
    justifyContent: "flex-end",
    position: "absolute",
  },
  eyeIcon: {
    top: 414,
    left: 264,
    width: 25,
    height: 25,
    position: "absolute",
  },
  logIn: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default LogIn;
