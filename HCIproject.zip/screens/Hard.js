import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Linking,
  Modal,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const Hard = () => {
  const navigation = useNavigation();
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.hard}>
        <View style={[styles.hardChild, styles.hardChildLayout]} />
        <View style={[styles.hardItem, styles.hardChildLayout]} />
        <Text style={[styles.deadlift, styles.hard1Clr]}>Deadlift</Text>
        <View style={[styles.hardInner, styles.hardChildLayout]} />
        <Text style={[styles.barbellCurl, styles.barbellTypo]}>
          Barbell Curl
        </Text>
        <View style={[styles.rectangleView, styles.hardChildLayout]} />
        <Text style={[styles.ezBarSkull, styles.hard1Clr]}>
          EZ Bar Skull Crushers
        </Text>
        <View style={[styles.hardChild1, styles.hardChildLayout]} />
        <Text style={[styles.arnoldPress, styles.barbellTypo]}>
          Arnold Press
        </Text>
        <View style={[styles.hardChild2, styles.hardChildLayout]} />
        <Text style={[styles.theBarbellRow, styles.theBarbellRowPosition]}>
          The barbell row is a two step move. You lift the barbell from the
          ground and then angle your chest parallel to the ground so you’re
          slightly bent over. Then, you lift and lower the barbell in a series
          of reps.
        </Text>
        <Text style={[styles.barbellRow, styles.barbellTypo]}>Barbell Row</Text>
        <View style={[styles.hardChild3, styles.hardChildLayout]} />
        <Text style={[styles.bulgarianSplitSquat, styles.hard1Clr]}>
          Bulgarian Split Squat
        </Text>
        <Text style={[styles.hard1, styles.hard1Clr]}>Hard</Text>
        <Text style={[styles.inclineBarbellBench, styles.hard1Clr]}>
          Incline Barbell Bench Press
        </Text>
        <Pressable
          style={[styles.rectangleParent, styles.groupChildLayout]}
          onPress={() => navigation.navigate("WorkoutPlans")}
        >
          <View style={[styles.groupChild, styles.groupPosition1]} />
          <Text style={[styles.backToChoose, styles.aboutUs1Typo]}>
            Back to Choose Plans
          </Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleGroup, styles.groupLayout]}
          onPress={() =>
            Linking.openURL("file:///C:/Users/PC/Downloads/hard1.pdf")
          }
        >
          <View style={[styles.groupItem, styles.groupLayout]} />
          <Text style={[styles.downloadPlan, styles.searchTypo]}>
            Download Plan!
          </Text>
        </Pressable>
        <Text style={[styles.thisPlanIs, styles.hard1Clr]}>
          This plan is best for people who want to challenge themselves.
          Recommended for more experienced and stronger individuals, Also, this
          plan will lead to far more muscle gain.
        </Text>
        <View style={[styles.rectangleContainer, styles.groupInnerLayout]}>
          <View style={[styles.groupInner, styles.groupInnerLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.logoLayout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <View style={styles.groupPosition}>
          <View style={[styles.groupChild1, styles.pngwing1Position]} />
          <View style={[styles.groupChild2, styles.groupPosition]} />
          <Pressable
            style={[styles.logo, styles.logoLayout]}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.searchTypo]}>Search...</Text>
        </View>
        <Text
          style={[styles.thisIsA, styles.thisIsAPosition]}
        >{`This is a pressing movement similar to a regular press but the difference is the incline is set to 30 degrees to target more of the upper chest. Most people have less developed upper chest so this will be certainly a more challenging exercise `}</Text>
        <Text
          style={[styles.bssIsA, styles.bssIsAPosition]}
        >{`BSS is a variation of a squat where one leg is elevated on a surface and other performs a squat, receiving most of the load. It is one the most exhausting exercises and should be first done with no weight. 
`}</Text>
        <Text
          style={[styles.inOneFluid, styles.inOneFluidPosition]}
        >{`In one fluid motion, raise the dumbbells and rotate the palms of your head to face forward - keep lifting until your arms are extended straight above you. Pause and then reverse the move and repeat. It can be done seated or standing. `}</Text>
        <Text
          style={[styles.skullCrushersOr, styles.skullCrushersOrPosition]}
        >{`Skull crushers or triceps extensions work all 3 heads of the triceps. It is done by laying back on a bench and bending your elbows. `}</Text>
        <Text
          style={[styles.aBarbellCurl, styles.aBarbellCurlTypo]}
        >{`A barbell curl is a variation of the biceps curl. Perform barbell curls by grabbing a barbell with a shoulder-width supinated grip. Hinge your elbows, and lift the barbell towards your chest. `}</Text>
        <Text
          style={[styles.theDeadliftIs, styles.theDeadliftIsLayout]}
        >{`The deadlift is a weight training exercise in which a loaded barbell is lifted off the ground to the level of the hips, torso perpendicular to the floor, before being placed back on the ground. `}</Text>
        <Image
          style={styles.exerciseIcon}
          contentFit="cover"
          source={require("../assets/exercise.png")}
        />
        <Image
          style={styles.exerciseIcon1}
          contentFit="cover"
          source={require("../assets/exercise1.png")}
        />
        <Image
          style={styles.exerciseIcon2}
          contentFit="cover"
          source={require("../assets/exercise2.png")}
        />
        <Image
          style={[styles.exerciseIcon3, styles.exerciseIconLayout]}
          contentFit="cover"
          source={require("../assets/exercise3.png")}
        />
        <Image
          style={[styles.exerciseIcon4, styles.theDeadliftIsLayout]}
          contentFit="cover"
          source={require("../assets/exercise4.png")}
        />
        <Image
          style={[styles.exerciseIcon5, styles.exerciseIconLayout]}
          contentFit="cover"
          source={require("../assets/exercise5.png")}
        />
        <Image
          style={styles.exerciseIcon6}
          contentFit="cover"
          source={require("../assets/exercise6.png")}
        />
        <Text style={[styles.difficultyHard, styles.thisIsAPosition]}>
          Difficulty: Hard
        </Text>
        <Text style={[styles.difficultyHard1, styles.bssIsAPosition]}>
          Difficulty: Hard
        </Text>
        <Text style={[styles.difficultyHard2, styles.theBarbellRowPosition]}>
          Difficulty: Hard
        </Text>
        <Text style={[styles.difficultyHard3, styles.inOneFluidPosition]}>
          Difficulty: Hard
        </Text>
        <Text style={[styles.difficultyMedium, styles.aBarbellCurlTypo]}>
          Difficulty: Medium
        </Text>
        <Text style={[styles.difficultyHard4, styles.theDeadliftIsTypo]}>
          Difficulty: Hard
        </Text>
        <Text
          style={[styles.difficultyMedium1, styles.skullCrushersOrPosition]}
        >
          Difficulty: Medium
        </Text>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  hardChildLayout: {
    height: 107,
    width: 300,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.white,
    position: "absolute",
  },
  hard1Clr: {
    color: Color.black,
    position: "absolute",
  },
  barbellTypo: {
    left: 35,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  theBarbellRowPosition: {
    left: 111,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  groupChildLayout: {
    height: 20,
    width: 111,
    position: "absolute",
  },
  groupPosition1: {
    left: 0,
    borderRadius: Border.br_xl,
    top: 0,
  },
  aboutUs1Typo: {
    height: 11,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  groupLayout: {
    height: 23,
    width: 111,
    position: "absolute",
  },
  searchTypo: {
    height: 13,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  groupInnerLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  logoLayout: {
    height: 15,
    position: "absolute",
  },
  pngwing1Position: {
    top: 7,
    height: 20,
    position: "absolute",
  },
  groupPosition: {
    height: 33,
    width: 360,
    left: 0,
    top: 0,
    position: "absolute",
  },
  thisIsAPosition: {
    left: 104,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  bssIsAPosition: {
    left: 127,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  inOneFluidPosition: {
    left: 108,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  skullCrushersOrPosition: {
    left: 128,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  aBarbellCurlTypo: {
    left: 99,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  theDeadliftIsLayout: {
    height: 72,
    position: "absolute",
  },
  exerciseIconLayout: {
    width: 84,
    position: "absolute",
  },
  theDeadliftIsTypo: {
    left: 165,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  hardChild: {
    top: 220,
    left: 30,
  },
  hardItem: {
    top: 1000,
    left: 30,
  },
  deadlift: {
    top: 1007,
    textAlign: "center",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 38,
  },
  hardInner: {
    top: 870,
    left: 30,
  },
  barbellCurl: {
    top: 877,
  },
  rectangleView: {
    top: 736,
    left: 24,
  },
  ezBarSkull: {
    top: 741,
    textAlign: "center",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 30,
  },
  hardChild1: {
    top: 610,
    left: 30,
  },
  arnoldPress: {
    top: 614,
  },
  hardChild2: {
    top: 478,
    left: 30,
  },
  theBarbellRow: {
    top: 505,
    width: 216,
    textAlign: "justify",
    fontSize: FontSize.size_3xs,
  },
  barbellRow: {
    top: 484,
  },
  hardChild3: {
    top: 347,
    left: 31,
  },
  bulgarianSplitSquat: {
    top: 353,
    left: 23,
    width: 138,
    textAlign: "center",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  hard1: {
    top: 85,
    left: 157,
    fontSize: FontSize.size_6xl,
    fontFamily: FontFamily.jockeyOneRegular,
    textAlign: "center",
  },
  inclineBarbellBench: {
    top: 227,
    left: 34,
    textAlign: "center",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  groupChild: {
    borderRadius: Border.br_xl,
    height: 20,
    width: 111,
    position: "absolute",
    backgroundColor: Color.white,
  },
  backToChoose: {
    top: 4,
    left: 4,
    width: 104,
    fontSize: FontSize.size_xs,
    height: 11,
    position: "absolute",
  },
  rectangleParent: {
    top: 1177,
    left: 222,
  },
  groupItem: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
    left: 0,
    top: 0,
  },
  downloadPlan: {
    top: 5,
    left: 3,
    color: Color.white,
    width: 104,
    textAlign: "center",
  },
  rectangleGroup: {
    top: 1145,
    left: 219,
  },
  thisPlanIs: {
    top: 128,
    left: 28,
    width: 296,
    textAlign: "justify",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  groupInner: {
    backgroundColor: Color.gray_200,
    top: 0,
    width: 360,
  },
  aboutUs1: {
    width: 39,
    fontSize: FontSize.size_3xs,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  contact1: {
    width: 36,
    fontSize: FontSize.size_3xs,
  },
  contact: {
    top: 20,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  twitter1: {
    left: 336,
    width: 15,
    height: 15,
    top: 12,
  },
  instagram1: {
    left: 286,
    width: 15,
    height: 15,
    top: 12,
  },
  facebook1: {
    left: 311,
    width: 15,
    height: 15,
    top: 12,
  },
  rectangleContainer: {
    top: 1226,
  },
  groupChild1: {
    left: 200,
    width: 124,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  groupChild2: {
    backgroundColor: Color.gray_200,
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    color: Color.gray_100,
    width: 50,
    textAlign: "left",
  },
  thisIsA: {
    top: 244,
    width: 217,
    textAlign: "justify",
  },
  bssIsA: {
    top: 370,
    width: 197,
    height: 53,
    textAlign: "justify",
  },
  inOneFluid: {
    top: 633,
    width: 215,
    textAlign: "justify",
  },
  skullCrushersOr: {
    top: 763,
    width: 187,
    textAlign: "justify",
  },
  aBarbellCurl: {
    top: 894,
    width: 227,
  },
  theDeadliftIs: {
    top: 1006,
    width: 149,
    left: 165,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "justify",
  },
  exerciseIcon: {
    top: 243,
    left: 37,
    width: 62,
    height: 81,
    position: "absolute",
  },
  exerciseIcon1: {
    top: 383,
    left: 36,
    width: 79,
    height: 55,
    position: "absolute",
  },
  exerciseIcon2: {
    top: 510,
    left: 47,
    width: 46,
    height: 60,
    position: "absolute",
  },
  exerciseIcon3: {
    top: 631,
    height: 65,
    left: 24,
  },
  exerciseIcon4: {
    top: 897,
    width: 59,
    left: 31,
  },
  exerciseIcon5: {
    top: 768,
    height: 64,
    left: 31,
  },
  exerciseIcon6: {
    top: 1027,
    width: 101,
    height: 62,
    left: 38,
    position: "absolute",
  },
  difficultyHard: {
    top: 312,
    textAlign: "left",
  },
  difficultyHard1: {
    top: 438,
    textAlign: "left",
  },
  difficultyHard2: {
    top: 563,
    textAlign: "left",
    fontSize: FontSize.size_3xs,
  },
  difficultyHard3: {
    top: 703,
    textAlign: "left",
  },
  difficultyMedium: {
    top: 957,
  },
  difficultyHard4: {
    top: 1089,
    textAlign: "left",
    position: "absolute",
  },
  difficultyMedium1: {
    top: 824,
    textAlign: "left",
  },
  hard: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 1265,
    overflow: "hidden",
    width: "100%",
  },
});

export default Hard;
