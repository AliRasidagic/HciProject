import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Modal,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const Home = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.home}>
        <View style={styles.homeChild} />
        <Image
          style={styles.homePictureIcon}
          contentFit="cover"
          source={require("../assets/home-picture.png")}
        />
        <Text
          style={[
            styles.welcomeToAll4sportContainer,
            styles.everythingIsPossibleFlexBox,
          ]}
        >
          <Text style={styles.welcomeToAll4sport}>{`Welcome to All4Sport!
`}</Text>
          <Text style={styles.weProvideAllTypo}>
            We Provide All Tools For Your Body. Free.
          </Text>
        </Text>
        <Pressable
          style={[styles.rectangleParent, styles.groupChildLayout]}
          onPress={() => navigation.navigate("Exercises")}
        >
          <View style={[styles.groupChild, styles.groupPosition]} />
          <Text style={styles.learnMore}>Learn More</Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleGroup, styles.groupLayout1]}
          onPress={() => navigation.navigate("Exercises")}
        >
          <View style={[styles.groupItem, styles.groupLayout1]} />
          <Text style={styles.startYourJourney}>Start Your Journey!</Text>
        </Pressable>
        <Text style={[styles.effectiveAndProven, styles.multipleLevelsOfTypo]}>
          Effective and proven exercises!
        </Text>
        <Text
          style={[
            styles.exercisesSpecificallyMade,
            styles.multipleLevelsOfTypo,
          ]}
        >
          Exercises specifically made for you!
        </Text>
        <Text style={[styles.multipleLevelsOf, styles.multipleLevelsOfTypo]}>
          Multiple levels of difficulty!
        </Text>
        <View style={styles.rectanglePosition}>
          <View style={[styles.groupInner, styles.pngwing1Position]} />
          <View style={[styles.rectangleView, styles.rectanglePosition]} />
          <Image
            style={styles.logoIcon}
            contentFit="cover"
            source={require("../assets/logo.png")}
          />
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={styles.search}>Search...</Text>
        </View>
        <Image
          style={[styles.icon1, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/icon.png")}
        />
        <Image
          style={[styles.icon2, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/icon1.png")}
        />
        <Image
          style={[styles.icon3, styles.iconLayout1]}
          contentFit="cover"
          source={require("../assets/icon2.png")}
        />
        <Pressable
          style={[styles.icon4, styles.iconLayout]}
          onPress={() => navigation.navigate("Simple")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/icon3.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.icon6, styles.iconLayout]}
          onPress={() => navigation.navigate("Medium")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/icon4.png")}
          />
        </Pressable>
        <Pressable
          style={[styles.icon8, styles.iconLayout]}
          onPress={() => navigation.navigate("Hard")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/icon5.png")}
          />
        </Pressable>
        <Text style={[styles.everythingIsPossible, styles.iconLayout1]}>
          Everything is possible!
        </Text>
        <Text
          style={styles.ourPlansAre}
        >{`Our plans are reliable, effective and most importantly customizable for each and every one of our users. We offer three levels of difficulty: easy; for people that do not have enough time to fully commit themselves, medium; for more experienced users, and hard; for the best results.

You will not regret using our plans, which focus on three main goals: maintaining bodyweight, building muscle and losing weight. With all these options, we guarantee all users will find something to suit them.

Most importantly; everything is completely free. Forever.`}</Text>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={[styles.groupChild1, styles.groupLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  everythingIsPossibleFlexBox: {
    textAlign: "center",
    color: Color.black,
  },
  groupChildLayout: {
    height: 26,
    width: 80,
    position: "absolute",
  },
  groupPosition: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
    top: 0,
    left: 0,
  },
  groupLayout1: {
    height: 27,
    width: 109,
    position: "absolute",
  },
  multipleLevelsOfTypo: {
    height: 28,
    fontSize: 12,
    top: 337,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  rectanglePosition: {
    height: 33,
    top: 0,
    width: 360,
    left: 0,
    position: "absolute",
  },
  iconLayout1: {
    height: 23,
    position: "absolute",
  },
  iconLayout: {
    height: 50,
    top: 480,
    width: 50,
    position: "absolute",
  },
  groupLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
  },
  twitter1Layout: {
    width: 15,
    top: 12,
    height: 15,
    position: "absolute",
  },
  homeChild: {
    top: 302,
    height: 76,
    width: 360,
    left: 0,
    backgroundColor: Color.gray_200,
    position: "absolute",
  },
  homePictureIcon: {
    top: 72,
    width: 350,
    height: 175,
    left: 5,
    position: "absolute",
  },
  welcomeToAll4sport: {
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
  },
  weProvideAllTypo: {
    fontFamily: FontFamily.graduateRegular,
    fontSize: FontSize.size_xl,
  },
  welcomeToAll4sportContainer: {
    top: 119,
    left: 49,
    width: 262,
    height: 115,
    position: "absolute",
  },
  groupChild: {
    height: 26,
    width: 80,
    position: "absolute",
  },
  learnMore: {
    left: 9,
    fontSize: FontSize.size_sm,
    width: 62,
    height: 14,
    color: Color.white,
    fontFamily: FontFamily.frescaRegular,
    top: 6,
    textAlign: "center",
    position: "absolute",
  },
  rectangleParent: {
    top: 234,
    left: 140,
  },
  groupItem: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
    top: 0,
    left: 0,
  },
  startYourJourney: {
    width: 97,
    fontSize: FontSize.size_xs,
    left: 6,
    height: 14,
    color: Color.white,
    fontFamily: FontFamily.frescaRegular,
    top: 6,
    textAlign: "center",
    position: "absolute",
  },
  rectangleGroup: {
    top: 697,
    left: 126,
  },
  effectiveAndProven: {
    left: 3,
    width: 91,
  },
  exercisesSpecificallyMade: {
    left: 132,
    width: 98,
  },
  multipleLevelsOf: {
    left: 273,
    width: 79,
  },
  groupInner: {
    left: 200,
    backgroundColor: Color.white,
    width: 124,
    borderRadius: Border.br_xl,
    top: 7,
  },
  rectangleView: {
    backgroundColor: Color.gray_200,
    height: 33,
  },
  logoIcon: {
    top: 9,
    width: 120,
    height: 15,
    left: 5,
    position: "absolute",
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    color: Color.gray_100,
    textAlign: "left",
    height: 13,
    width: 50,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  icon1: {
    left: 37,
    width: 23,
    top: 314,
    height: 23,
  },
  icon2: {
    left: 169,
    width: 23,
    top: 314,
    height: 23,
  },
  icon3: {
    left: 301,
    width: 23,
    top: 314,
    height: 23,
  },
  icon4: {
    left: 35,
    height: 50,
    top: 480,
  },
  icon6: {
    left: 155,
  },
  icon8: {
    left: 275,
  },
  everythingIsPossible: {
    top: 425,
    left: 48,
    width: 265,
    fontFamily: FontFamily.graduateRegular,
    fontSize: FontSize.size_xl,
    textAlign: "center",
    color: Color.black,
  },
  ourPlansAre: {
    top: 556,
    width: 290,
    height: 121,
    fontSize: FontSize.size_3xs,
    left: 35,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  groupChild1: {
    top: 0,
    height: 39,
    backgroundColor: Color.gray_200,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  groupView: {
    top: 761,
  },
  home: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default Home;
