import React, { useState, useCallback } from "react";
import { Image } from "expo-image";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  Modal,
  Linking,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Description = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.description}>
        <Image
          style={styles.outlineManIcon}
          contentFit="cover"
          source={require("../assets/outline-man.png")}
        />
        <View style={[styles.descriptionChild, styles.rectangleLayout]} />
        <View style={[styles.descriptionItem, styles.rectangleLayout]} />
        <Text style={styles.describeYourself}>Describe Yourself!</Text>
        <Text style={[styles.height, styles.heightTypo]}>Height</Text>
        <View style={[styles.rectangleParent, styles.rectangleLayout]}>
          <View style={[styles.groupChild, styles.groupPosition]} />
          <Text style={[styles.gender, styles.ageTypo]}>Gender</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
          <View style={[styles.groupChild, styles.groupPosition]} />
          <Text style={[styles.age, styles.ageTypo]}>Age</Text>
        </View>
        <Text style={[styles.weight, styles.heightTypo]}>Weight</Text>
        <Pressable
          style={[styles.rectangleContainer, styles.groupPressablePosition]}
          onPress={() => navigation.navigate("WorkoutPlans")}
        >
          <View style={[styles.groupInner, styles.groupPosition]} />
          <Text style={[styles.submit, styles.submitTypo]}>Submit!</Text>
        </Pressable>
        <Pressable
          style={[styles.groupPressable, styles.groupPressablePosition]}
          onPress={() => navigation.navigate("Exercises")}
        >
          <View style={[styles.rectangleView, styles.groupPosition]} />
          <Text style={[styles.goBack, styles.submitTypo]}>Go back</Text>
        </Pressable>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={[styles.groupChild1, styles.pngwing1Position]} />
          <View style={[styles.groupChild2, styles.groupChildBg]} />
          <Pressable
            style={styles.logo}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.heightTypo]}>Search...</Text>
        </View>
        <View style={[styles.rectangleParent1, styles.groupChild3Layout]}>
          <View style={[styles.groupChild3, styles.groupChild3Layout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  rectangleLayout: {
    height: 30,
    width: 150,
    position: "absolute",
  },
  heightTypo: {
    color: Color.gray_100,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "left",
    position: "absolute",
  },
  groupPosition: {
    left: 0,
    top: 0,
    height: 30,
    borderRadius: Border.br_xl,
    position: "absolute",
  },
  ageTypo: {
    top: 6,
    color: Color.gray_100,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    position: "absolute",
  },
  groupPressablePosition: {
    top: 579,
    height: 30,
    width: 100,
    position: "absolute",
  },
  submitTypo: {
    top: 5,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    position: "absolute",
  },
  groupLayout: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupChildBg: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  groupChild3Layout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    textAlign: "center",
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    color: Color.black,
  },
  twitter1Layout: {
    width: 15,
    top: 12,
    height: 15,
    position: "absolute",
  },
  outlineManIcon: {
    top: 176,
    left: 130,
    height: 268,
    width: 100,
    position: "absolute",
  },
  descriptionChild: {
    backgroundColor: Color.white,
    borderRadius: Border.br_xl,
    left: 20,
    height: 30,
    top: 469,
  },
  descriptionItem: {
    left: 190,
    backgroundColor: Color.white,
    borderRadius: Border.br_xl,
    top: 469,
  },
  describeYourself: {
    top: 113,
    left: 72,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
    width: 216,
    height: 38,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  height: {
    top: 476,
    left: 34,
    height: 15,
    width: 45,
    fontSize: FontSize.size_base,
    color: Color.gray_100,
    fontFamily: FontFamily.frescaRegular,
  },
  groupChild: {
    width: 150,
    left: 0,
    backgroundColor: Color.white,
  },
  gender: {
    left: 13,
    width: 123,
    height: 15,
  },
  rectangleParent: {
    top: 516,
    left: 190,
  },
  age: {
    left: 14,
    height: 18,
    width: 45,
  },
  rectangleGroup: {
    top: 514,
    left: 20,
    height: 30,
  },
  weight: {
    top: 475,
    left: 203,
    width: 48,
    height: 15,
    fontSize: FontSize.size_base,
    color: Color.gray_100,
    fontFamily: FontFamily.frescaRegular,
  },
  groupInner: {
    backgroundColor: Color.midnightblue_200,
    width: 100,
  },
  submit: {
    left: 27,
    color: Color.white,
    width: 52,
    height: 16,
  },
  rectangleContainer: {
    left: 70,
  },
  rectangleView: {
    backgroundColor: Color.white,
    width: 100,
  },
  goBack: {
    left: 24,
    width: 51,
    height: 12,
    color: Color.black,
    top: 5,
  },
  groupPressable: {
    left: 190,
  },
  groupChild1: {
    left: 200,
    width: 124,
    backgroundColor: Color.white,
    borderRadius: Border.br_xl,
  },
  groupChild2: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
    height: 15,
    position: "absolute",
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    fontSize: FontSize.size_xs,
    width: 50,
    height: 13,
  },
  groupView: {
    top: 0,
    height: 33,
    width: 360,
  },
  groupChild3: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  rectangleParent1: {
    top: 761,
  },
  description: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default Description;
