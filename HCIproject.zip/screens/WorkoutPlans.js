import React, { useState, useCallback } from "react";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  Modal,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const WorkoutPlans = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.workoutPlans}>
        <Text style={styles.chooseYourPlan}>Choose Your Plan!</Text>
        <View style={[styles.rectangleParent, styles.groupLayout1]}>
          <View style={[styles.groupChild, styles.groupLayout1]} />
          <Text style={[styles.simple, styles.hardTypo]}>Simple</Text>
          <View style={[styles.starParent, styles.starPosition]}>
            <Image
              style={[styles.groupItem, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupInner, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.starIcon, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild1, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Text style={styles.timeConsuming}>Time consuming</Text>
            <Text style={[styles.difficulty, styles.difficultyPosition]}>
              Difficulty
            </Text>
          </View>
          <Text style={styles.thisSimplePlan}>
            This simple plan is primarily for people that want to exercise
            casually and/or do not have enough time to commit to exercising.
            Here you will find simple exercises that do not require gym
            equipment and can be done from the comfort of your home.
          </Text>
          <Text style={[styles.all4sport, styles.all4sportTypo1]}>
            All4Sport
          </Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout1]}>
          <View style={[styles.groupChild, styles.groupLayout1]} />
          <Text style={[styles.medium, styles.hardTypo]}>Medium</Text>
          <View style={[styles.starParent, styles.starPosition]}>
            <Image
              style={[styles.groupItem, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupInner, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.starIcon, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild5, styles.groupChildPosition1]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild6, styles.groupChildPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild7, styles.groupChildPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild1, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Text style={styles.timeConsuming}>Time consuming</Text>
            <Text style={[styles.difficulty1, styles.difficultyPosition]}>
              Difficulty
            </Text>
          </View>
          <Text style={styles.thisSimplePlan}>
            Medium plan is not much harder than the simple one, but it is more
            time consuming and as such it is perfect for users that have more
            time on their hands, but do not want the hardest exercises. Note:
            some gym equipment is required.
          </Text>
          <Text style={[styles.all4sport1, styles.all4sportTypo]}>
            All4Sport
          </Text>
        </View>
        <View style={[styles.rectangleContainer, styles.groupLayout1]}>
          <View style={[styles.groupChild, styles.groupLayout1]} />
          <Text style={[styles.hard, styles.hardTypo]}>Hard</Text>
          <View style={[styles.starContainer, styles.starPosition]}>
            <Image
              style={[styles.groupItem, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupInner, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.starIcon, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild5, styles.groupChildPosition1]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild6, styles.groupChildPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild15, styles.iconGroupLayout]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild16, styles.groupChildPosition1]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild7, styles.groupChildPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Image
              style={[styles.groupChild1, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/star-1.png")}
            />
            <Text style={styles.timeConsuming}>Time consuming</Text>
            <Text style={[styles.difficulty, styles.difficultyPosition]}>
              Difficulty
            </Text>
          </View>
          <Text
            style={styles.thisSimplePlan}
          >{`The hardest exercises for the strongest! In this plan there are a lot of exercises and the difficulty greatly increases from the medium plan. This plan requires the most attention and time but also promises the best results. Note: gym equipment required.
`}</Text>
          <Text style={[styles.all4sport2, styles.all4sportTypo]}>
            All4Sport
          </Text>
        </View>
        <Pressable
          style={[styles.groupPressable, styles.groupParentLayout]}
          onPress={() => navigation.navigate("Simple")}
        >
          <View style={[styles.groupChild19, styles.groupParentLayout]} />
          <Text style={[styles.checkThePlan, styles.searchTypo]}>
            Check the Plan Out!
          </Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleParent1, styles.groupParentLayout]}
          onPress={() => navigation.navigate("Medium")}
        >
          <View style={[styles.groupChild19, styles.groupParentLayout]} />
          <Text style={[styles.checkThePlan, styles.searchTypo]}>
            Check the Plan Out!
          </Text>
        </Pressable>
        <Pressable
          style={[styles.rectangleParent2, styles.groupParentLayout]}
          onPress={() => navigation.navigate("Hard")}
        >
          <View style={[styles.groupChild19, styles.groupParentLayout]} />
          <Text style={[styles.checkThePlan, styles.searchTypo]}>
            Check the Plan Out!
          </Text>
        </Pressable>
        <Text style={[styles.plansAreAdapted, styles.logoLayout]}>
          Plans are adapted to your body
        </Text>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={[styles.groupChild22, styles.pngwing1Position]} />
          <View style={[styles.groupChild23, styles.groupChildBg]} />
          <Pressable
            style={[styles.logo, styles.logoLayout]}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={[styles.searchIcon, styles.all4sportPosition]}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.searchTypo]}>Search...</Text>
        </View>
        <View style={[styles.rectangleParent3, styles.groupChild24Layout]}>
          <View style={[styles.groupChild24, styles.groupChild24Layout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.all4sportTypo1]}>
              About Us
            </Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.all4sportTypo1]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.all4sportTypo1]}>
              Contact
            </Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  groupLayout1: {
    height: 107,
    width: 300,
    position: "absolute",
  },
  hardTypo: {
    height: 26,
    fontFamily: FontFamily.graduateRegular,
    fontSize: FontSize.size_xl,
    top: 5,
    left: 6,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  starPosition: {
    height: 42,
    top: 37,
    position: "absolute",
  },
  iconGroupLayout: {
    height: 10,
    width: 10,
  },
  groupPosition: {
    left: 12,
    height: 10,
    width: 10,
    position: "absolute",
  },
  difficultyPosition: {
    top: 22,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_5xs,
    height: 10,
    left: 0,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  all4sportTypo1: {
    height: 11,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
  },
  groupChildPosition1: {
    left: 36,
    height: 10,
    width: 10,
    position: "absolute",
  },
  groupChildPosition: {
    left: 24,
    height: 10,
    width: 10,
    position: "absolute",
  },
  all4sportTypo: {
    height: 14,
    width: 40,
    top: 11,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  groupParentLayout: {
    height: 23,
    width: 111,
    position: "absolute",
  },
  searchTypo: {
    height: 13,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  logoLayout: {
    height: 15,
    position: "absolute",
  },
  groupLayout: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupChildBg: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  all4sportPosition: {
    top: 12,
    position: "absolute",
  },
  groupChild24Layout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  twitter1Layout: {
    width: 15,
    height: 15,
    top: 12,
    position: "absolute",
  },
  chooseYourPlan: {
    top: 99,
    left: 60,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
    width: 228,
    height: 43,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.white,
    left: 0,
    top: 0,
  },
  simple: {
    width: 78,
  },
  groupItem: {
    top: 10,
    left: 0,
    position: "absolute",
  },
  groupInner: {
    top: 32,
  },
  starIcon: {
    top: 32,
    left: 0,
    position: "absolute",
  },
  groupChild1: {
    top: 10,
  },
  timeConsuming: {
    left: 1,
    width: 54,
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_5xs,
    height: 10,
    top: 0,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  difficulty: {
    width: 35,
  },
  starParent: {
    width: 55,
    left: 234,
  },
  thisSimplePlan: {
    textAlign: "justify",
    width: 216,
    height: 59,
    fontSize: FontSize.size_3xs,
    left: 7,
    fontFamily: FontFamily.frescaRegular,
    top: 37,
    color: Color.black,
    position: "absolute",
  },
  all4sport: {
    left: 232,
    width: 43,
    top: 12,
    position: "absolute",
  },
  rectangleParent: {
    top: 209,
    left: 26,
    width: 300,
  },
  medium: {
    width: 90,
  },
  groupChild5: {
    top: 10,
  },
  groupChild6: {
    top: 10,
  },
  groupChild7: {
    top: 32,
  },
  difficulty1: {
    width: 33,
  },
  all4sport1: {
    left: 233,
  },
  rectangleGroup: {
    top: 375,
    left: 26,
    width: 300,
  },
  hard: {
    width: 60,
  },
  groupChild15: {
    left: 48,
    top: 32,
    position: "absolute",
  },
  groupChild16: {
    top: 32,
  },
  starContainer: {
    width: 58,
    left: 233,
  },
  all4sport2: {
    left: 234,
  },
  rectangleContainer: {
    top: 541,
    left: 26,
    width: 300,
  },
  groupChild19: {
    backgroundColor: Color.midnightblue_200,
    borderRadius: Border.br_xl,
    left: 0,
    top: 0,
  },
  checkThePlan: {
    color: Color.white,
    width: 96,
    left: 7,
    height: 13,
    top: 5,
    textAlign: "center",
  },
  groupPressable: {
    top: 334,
    left: 212,
  },
  rectangleParent1: {
    top: 500,
    left: 212,
  },
  rectangleParent2: {
    top: 666,
    left: 212,
  },
  plansAreAdapted: {
    top: 142,
    left: 63,
    width: 227,
    fontSize: FontSize.size_xs,
    height: 15,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
  },
  groupChild22: {
    left: 200,
    width: 124,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
  },
  groupChild23: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
  },
  searchIcon: {
    left: 307,
    height: 10,
    width: 10,
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    color: Color.gray_100,
    textAlign: "left",
    width: 50,
    left: 212,
    top: 10,
  },
  groupView: {
    top: 0,
  },
  groupChild24: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  rectangleParent3: {
    top: 761,
  },
  workoutPlans: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default WorkoutPlans;
