import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, Color, FontSize } from "../GlobalStyles";

const ChangePassword = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.changePassword}>
      <View style={[styles.rectangleParent, styles.rectangleGroupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.newPassword, styles.passwordTypo]}>
          New password
        </Text>
      </View>
      <View style={[styles.rectangleGroup, styles.rectangleGroupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.newPassword, styles.passwordTypo]}>
          Confirm password
        </Text>
      </View>
      <View style={[styles.rectangleContainer, styles.rectangleGroupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.newPassword, styles.passwordTypo]}>E-mail</Text>
      </View>
      <Pressable
        style={styles.cancel}
        onPress={() => navigation.navigate("LogIn")}
      >
        <Text style={[styles.cancel1, styles.passwordTypo]}>Cancel</Text>
      </Pressable>
      <Pressable
        style={[styles.groupPressable, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("LogIn")}
      >
        <View style={[styles.rectangleView, styles.groupChildLayout]} />
        <Text style={[styles.changePassword1, styles.passwordTypo]}>
          Change password
        </Text>
      </Pressable>
      <Image
        style={styles.logoIcon}
        contentFit="cover"
        source={require("../assets/logo1.png")}
      />
      <Text style={styles.all4sportLlc}>© 2023, All4Sport, LLC.</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleGroupLayout: {
    height: 54,
    width: 250,
    left: 55,
    position: "absolute",
  },
  groupChildLayout: {
    borderRadius: Border.br_xl,
    left: 0,
    top: 0,
    height: 54,
    width: 250,
    position: "absolute",
  },
  passwordTypo: {
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  newPassword: {
    top: 15,
    left: 22,
    width: 188,
    height: 24,
    color: Color.gray_100,
    textAlign: "left",
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleParent: {
    top: 330,
  },
  rectangleGroup: {
    top: 395,
  },
  rectangleContainer: {
    top: 265,
  },
  cancel1: {
    fontSize: FontSize.size_base,
    textDecoration: "underline",
    width: 42,
    height: 18,
    color: Color.gray_100,
    textAlign: "left",
  },
  cancel: {
    left: 159,
    top: 724,
    position: "absolute",
  },
  rectangleView: {
    backgroundColor: Color.midnightblue_200,
  },
  changePassword1: {
    top: 17,
    left: 51,
    color: Color.white,
    width: 148,
    height: 21,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  groupPressable: {
    top: 659,
  },
  logoIcon: {
    top: 60,
    left: 30,
    width: 300,
    height: 38,
    position: "absolute",
  },
  all4sportLlc: {
    top: 775,
    left: 109,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    textAlign: "center",
    width: 142,
    height: 11,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  changePassword: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default ChangePassword;
