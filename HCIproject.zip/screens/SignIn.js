import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, Color, FontSize, Padding } from "../GlobalStyles";

const SignIn = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.signIn}>
      <View style={[styles.rectangleParent, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.password, styles.cancel1Typo]}>Password</Text>
      </View>
      <View style={[styles.rectangleGroup, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.repeatPassword, styles.signIn1Typo]}>
          Repeat password
        </Text>
      </View>
      <View style={[styles.rectangleContainer, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.repeatPassword, styles.signIn1Typo]}>E-mail</Text>
      </View>
      <View style={[styles.groupView, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.repeatPassword, styles.signIn1Typo]}>
          Name and Surname
        </Text>
      </View>
      <Pressable
        style={styles.cancel}
        onPress={() => navigation.navigate("StartingPage")}
      >
        <Text style={[styles.cancel1, styles.cancel1Typo]}>Cancel</Text>
      </Pressable>
      <Pressable
        style={[styles.groupPressable, styles.groupLayout]}
        onPress={() => navigation.navigate("Home")}
      >
        <View style={[styles.groupChild1, styles.groupChildLayout]} />
        <Text style={[styles.signIn1, styles.signIn1Layout]}>Sign In</Text>
      </Pressable>
      <Image
        style={styles.logoIcon}
        contentFit="cover"
        source={require("../assets/logo1.png")}
      />
      <Text style={[styles.all4sportLlc, styles.rememberMeClr]}>
        © 2023, All4Sport, LLC.
      </Text>
      <Image
        style={[styles.eyeIcon, styles.signIn1Layout]}
        contentFit="cover"
        source={require("../assets/eye.png")}
      />
      <Text style={[styles.rememberMe, styles.rememberMeClr]}>Remember me</Text>
      <View style={[styles.toggle, styles.toggleLayout]}>
        <Image
          style={[styles.baseSwitchIcon, styles.toggleLayout]}
          contentFit="cover"
          source={require("../assets/baseswitch-icon.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 54,
    width: 250,
    left: 55,
    position: "absolute",
  },
  groupChildLayout: {
    borderRadius: Border.br_xl,
    left: 0,
    top: 0,
    height: 54,
    width: 250,
    position: "absolute",
  },
  cancel1Typo: {
    fontFamily: FontFamily.frescaRegular,
    textAlign: "left",
    color: Color.gray_100,
  },
  signIn1Typo: {
    top: 15,
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_xl,
  },
  signIn1Layout: {
    height: 25,
    position: "absolute",
  },
  rememberMeClr: {
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  toggleLayout: {
    height: 20,
    overflow: "hidden",
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  password: {
    top: 16,
    width: 143,
    height: 22,
    textAlign: "left",
    color: Color.gray_100,
    fontSize: FontSize.size_xl,
    left: 21,
    position: "absolute",
  },
  rectangleParent: {
    top: 395,
  },
  repeatPassword: {
    width: 188,
    height: 24,
    color: Color.gray_100,
    left: 21,
    position: "absolute",
  },
  rectangleGroup: {
    top: 460,
  },
  rectangleContainer: {
    top: 330,
  },
  groupView: {
    top: 265,
  },
  cancel1: {
    fontSize: FontSize.size_base,
    textDecoration: "underline",
    width: 42,
    height: 18,
    textAlign: "left",
    color: Color.gray_100,
  },
  cancel: {
    left: 159,
    top: 724,
    position: "absolute",
  },
  groupChild1: {
    backgroundColor: Color.midnightblue_200,
  },
  signIn1: {
    left: 96,
    color: Color.white,
    width: 57,
    top: 15,
    textAlign: "left",
    fontFamily: FontFamily.frescaRegular,
    fontSize: FontSize.size_xl,
  },
  groupPressable: {
    top: 659,
  },
  logoIcon: {
    top: 60,
    left: 30,
    width: 300,
    height: 38,
    position: "absolute",
  },
  all4sportLlc: {
    top: 775,
    left: 109,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    width: 142,
    height: 11,
  },
  eyeIcon: {
    top: 410,
    left: 267,
    width: 25,
  },
  rememberMe: {
    top: 528,
    left: 76,
    width: 120,
    height: 21,
    textAlign: "left",
    fontSize: FontSize.size_xl,
  },
  baseSwitchIcon: {
    borderRadius: Border.br_980xl,
    width: 21,
  },
  toggle: {
    top: 529,
    left: 198,
    borderRadius: Border.br_xs,
    backgroundColor: Color.midnightblue_100,
    width: 36,
    flexDirection: "row",
    padding: Padding.p_11xs,
    alignItems: "center",
    justifyContent: "flex-end",
    position: "absolute",
  },
  signIn: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SignIn;
