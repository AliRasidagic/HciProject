import React, { useState, useCallback } from "react";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  Modal,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const AboutUs = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.aboutUs}>
        <Text
          style={[styles.bodybuildingAndFitness, styles.contact3Typo]}
        >{`Bodybuilding and fitness in general do not have to be complicated.  We at All4Sport understand that we live in a very fast environment where not everyone can have enough time to train and live a healthy lifestyle. In a world where there are an infinite number of influencers, articles, blogs, commercials, who give misleading and overwhelming information our job is to create simple programs that anyone can follow and still be productive with other everyday things. Our 3 programs offer simple exercises to more complex exercises that in the long run lead to a healthier and more productive lifestyle. So do not waste any more time, get started as soon as possible. 
`}</Text>
        <Text style={styles.aboutUs1}>About Us!</Text>
        <Text style={[styles.thankYouFor, styles.forTypo]}>
          Thank you for trusting us!
        </Text>
        <Text style={[styles.forAnyInformation, styles.forTypo]}>
          For any information do not hesitate to contact us!
        </Text>
        <View style={[styles.rectangleParent, styles.groupItemLayout]}>
          <View style={[styles.groupChild, styles.pngwing1Position]} />
          <View style={[styles.groupItem, styles.groupBg]} />
          <Pressable
            style={[styles.logo, styles.logoLayout]}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={styles.search}>Search...</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <View style={[styles.groupInner, styles.groupLayout]} />
          <Pressable
            style={[styles.aboutUs2, styles.contactPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs3, styles.aboutUs3Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs3Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Pressable
            style={[styles.contact, styles.contactPosition]}
            onPress={() => navigation.navigate("Contact")}
          >
            <Text style={[styles.contact1, styles.aboutUs3Typo]}>Contact</Text>
          </Pressable>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <Pressable
          style={[styles.logo1, styles.logoLayout]}
          onPress={() => navigation.navigate("Home")}
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/logo.png")}
          />
        </Pressable>
        <Pressable
          style={styles.contact2}
          onPress={() => navigation.navigate("Contact")}
        >
          <Text style={[styles.contact3, styles.contact3Typo]}>Contact</Text>
        </Pressable>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  contact3Typo: {
    textAlign: "justify",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  forTypo: {
    fontSize: FontSize.size_xl,
    height: 43,
    width: 228,
    textAlign: "center",
    left: 66,
    color: Color.black,
    position: "absolute",
  },
  groupItemLayout: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  pngwing1Position: {
    top: 7,
    height: 20,
    position: "absolute",
  },
  groupBg: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  logoLayout: {
    height: 15,
    width: 120,
    position: "absolute",
  },
  groupLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  contactPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs3Typo: {
    height: 11,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.black,
    fontFamily: FontFamily.frescaRegular,
  },
  twitter1Layout: {
    width: 15,
    top: 12,
    height: 15,
    position: "absolute",
  },
  bodybuildingAndFitness: {
    top: 196,
    left: 47,
    fontSize: FontSize.size_sm,
    width: 279,
    height: 226,
    position: "absolute",
  },
  aboutUs1: {
    top: 115,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
    height: 43,
    width: 228,
    textAlign: "center",
    left: 66,
    color: Color.black,
    position: "absolute",
  },
  thankYouFor: {
    top: 475,
    fontFamily: FontFamily.graduateRegular,
  },
  forAnyInformation: {
    top: 592,
    fontFamily: FontFamily.frescaRegular,
  },
  groupChild: {
    left: 200,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
    width: 124,
    height: 20,
  },
  groupItem: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  logo: {
    left: 5,
    top: 9,
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
    height: 20,
  },
  search: {
    top: 10,
    left: 212,
    fontSize: FontSize.size_xs,
    color: Color.gray_100,
    textAlign: "left",
    width: 50,
    height: 13,
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  rectangleParent: {
    top: 0,
    width: 360,
    left: 0,
  },
  groupInner: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs3: {
    width: 39,
  },
  aboutUs2: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    width: 36,
  },
  contact: {
    top: 20,
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  rectangleGroup: {
    top: 761,
  },
  logo1: {
    left: 120,
    top: 452,
  },
  contact3: {
    fontSize: FontSize.size_base,
    textDecoration: "underline",
    width: 53,
    height: 20,
  },
  contact2: {
    left: 153,
    top: 644,
    position: "absolute",
  },
  aboutUs: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default AboutUs;
