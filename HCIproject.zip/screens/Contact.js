import React, { useState, useCallback } from "react";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  Modal,
  Linking,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import Menu from "../components/Menu";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Contact = () => {
  const [pngwing1IconVisible, setPngwing1IconVisible] = useState(false);
  const navigation = useNavigation();

  const openPngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(true);
  }, []);

  const closePngwing1Icon = useCallback(() => {
    setPngwing1IconVisible(false);
  }, []);

  return (
    <>
      <View style={styles.contact}>
        <Text
          style={[styles.contactInformation, styles.contactInformationFlexBox]}
        >
          Contact Information
        </Text>
        <View style={[styles.rectangleParent, styles.groupItemLayout]}>
          <View style={[styles.groupChild, styles.pngwing1Position]} />
          <View style={[styles.groupItem, styles.groupBg]} />
          <Pressable
            style={styles.logo}
            onPress={() => navigation.navigate("Home")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/logo.png")}
            />
          </Pressable>
          <Image
            style={styles.searchIcon}
            contentFit="cover"
            source={require("../assets/search.png")}
          />
          <Pressable
            style={[styles.pngwing1, styles.pngwing1Position]}
            onPress={openPngwing1Icon}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/pngwing-1.png")}
            />
          </Pressable>
          <Text style={[styles.search, styles.searchTypo]}>Search...</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <View style={[styles.groupInner, styles.groupLayout]} />
          <Pressable
            style={[styles.aboutUs, styles.aboutUsPosition]}
            onPress={() => navigation.navigate("AboutUs")}
          >
            <Text style={[styles.aboutUs1, styles.aboutUs1Typo]}>About Us</Text>
          </Pressable>
          <Text style={[styles.all4sportLlc, styles.aboutUs1Typo]}>
            © 2023, All4Sport, LLC.
          </Text>
          <Text style={[styles.contact1, styles.aboutUs1Typo]}>Contact</Text>
          <Pressable
            style={[styles.twitter1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://twitter.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/twitter-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.instagram1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.instagram.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/instagram-1.png")}
            />
          </Pressable>
          <Pressable
            style={[styles.facebook1, styles.twitter1Layout]}
            onPress={() => Linking.openURL("https://www.facebook.com/")}
          >
            <Image
              style={styles.icon}
              contentFit="cover"
              source={require("../assets/facebook-1.png")}
            />
          </Pressable>
        </View>
        <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
          <View style={[styles.rectangleView, styles.rectangleLayout]} />
          <Text style={[styles.instagramAll4sport, styles.searchTypo]}>
            Instagram: @<Text style={styles.all4sport}>all4sport</Text>
          </Text>
          <Text style={[styles.contactUsAtContainer, styles.all4sportPosition]}>
            <Text style={styles.contactUsAt}>Contact us at</Text>
            <Text style={styles.text}> :</Text>
          </Text>
          <Text
            style={[styles.eMailAll4sportgmailcom, styles.all4sportPosition]}
          >
            {`E-mail: `}
            <Text style={styles.all4sport}>all4sport@gmail.com</Text>
            {`  `}
          </Text>
          <Text style={[styles.facebookAll4sport, styles.all4sportPosition]}>
            {`Facebook: `}
            <Text style={styles.all4sport}>All4Sport</Text>
            {` `}
          </Text>
          <Text style={[styles.twitterAll4sport, styles.all4sportPosition]}>
            {`Twitter: `}
            <Text style={styles.all4sport}>@all4sport</Text>
            {` `}
          </Text>
        </View>
      </View>

      <Modal animationType="fade" transparent visible={pngwing1IconVisible}>
        <View style={styles.pngwing1IconOverlay}>
          <Pressable
            style={styles.pngwing1IconBg}
            onPress={closePngwing1Icon}
          />
          <Menu onClose={closePngwing1Icon} />
        </View>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  contactInformationFlexBox: {
    textAlign: "center",
    color: Color.black,
  },
  groupItemLayout: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  pngwing1Position: {
    height: 20,
    top: 7,
    position: "absolute",
  },
  groupBg: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  searchTypo: {
    fontFamily: FontFamily.frescaRegular,
    position: "absolute",
  },
  groupLayout: {
    height: 39,
    width: 360,
    left: 0,
    position: "absolute",
  },
  aboutUsPosition: {
    left: 6,
    position: "absolute",
  },
  aboutUs1Typo: {
    height: 11,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
  },
  twitter1Layout: {
    width: 15,
    top: 12,
    height: 15,
    position: "absolute",
  },
  rectangleLayout: {
    height: 146,
    width: 211,
    position: "absolute",
  },
  all4sportPosition: {
    left: 4,
    fontFamily: FontFamily.frescaRegular,
    textAlign: "center",
    color: Color.black,
    position: "absolute",
  },
  contactInformation: {
    top: 112,
    left: 59,
    fontSize: FontSize.size_13xl,
    fontFamily: FontFamily.jockeyOneRegular,
    width: 241,
    height: 43,
    position: "absolute",
  },
  groupChild: {
    left: 200,
    borderRadius: Border.br_xl,
    backgroundColor: Color.white,
    width: 124,
  },
  groupItem: {
    height: 33,
    width: 360,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  logo: {
    left: 5,
    top: 9,
    width: 120,
    height: 15,
    position: "absolute",
  },
  searchIcon: {
    left: 307,
    width: 10,
    height: 10,
    top: 12,
    position: "absolute",
  },
  pngwing1IconOverlay: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(113, 113, 113, 0.3)",
  },
  pngwing1IconBg: {
    position: "absolute",
    width: "100%",
    height: "100%",
    left: 0,
    top: 0,
  },
  pngwing1: {
    left: 329,
    width: 20,
  },
  search: {
    top: 10,
    left: 212,
    color: Color.gray_100,
    textAlign: "left",
    width: 50,
    height: 13,
    fontSize: FontSize.size_xs,
  },
  rectangleParent: {
    top: 0,
    width: 360,
  },
  groupInner: {
    backgroundColor: Color.gray_200,
    top: 0,
  },
  aboutUs1: {
    width: 39,
  },
  aboutUs: {
    top: 8,
  },
  all4sportLlc: {
    top: 14,
    left: 109,
    width: 142,
    position: "absolute",
  },
  contact1: {
    top: 20,
    width: 36,
    left: 6,
    position: "absolute",
  },
  twitter1: {
    left: 336,
  },
  instagram1: {
    left: 286,
  },
  facebook1: {
    left: 311,
  },
  rectangleGroup: {
    top: 761,
  },
  rectangleView: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.gray_200,
    top: 0,
    left: 0,
    width: 211,
  },
  all4sport: {
    textDecoration: "underline",
  },
  instagramAll4sport: {
    top: 67,
    left: 1,
    fontSize: FontSize.size_3xs,
    textAlign: "center",
    color: Color.black,
  },
  contactUsAt: {
    fontSize: FontSize.size_sm,
  },
  text: {
    fontSize: FontSize.size_xs,
  },
  contactUsAtContainer: {
    top: 8,
  },
  eMailAll4sportgmailcom: {
    top: 42,
    fontSize: FontSize.size_3xs,
  },
  facebookAll4sport: {
    top: 92,
    fontSize: FontSize.size_3xs,
  },
  twitterAll4sport: {
    top: 117,
    fontSize: FontSize.size_3xs,
  },
  rectangleContainer: {
    top: 208,
    left: 74,
  },
  contact: {
    backgroundColor: Color.paleturquoise,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default Contact;
