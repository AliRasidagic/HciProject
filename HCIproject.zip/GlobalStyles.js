/* fonts */
export const FontFamily = {
  frescaRegular: "Fresca_regular",
  jockeyOneRegular: "Jockey One_regular",
  graduateRegular: "Graduate_regular",
};
/* font sizes */
export const FontSize = {
  size_3xs: 10,
  size_xs: 12,
  size_sm: 14,
  size_13xl: 32,
  size_xl: 20,
  size_base: 16,
  size_6xl: 25,
  size_5xs: 8,
  size_xs_5: 12,
};
/* Colors */
export const Color = {
  paleturquoise: "#8cf0f0",
  black: "#000",
  gray_100: "rgba(0, 0, 0, 0.5)",
  gray_200: "rgba(255, 255, 255, 0.5)",
  white: "#fff",
  midnightblue_100: "#21005d",
  midnightblue_200: "#08065e",
};
/* Paddings */
export const Padding = {
  p_11xs: 2,
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_xl: 20,
  br_xs: 12,
  br_980xl: 999,
};
