const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import Contact from "./screens/Contact";
import ChangePassword from "./screens/ChangePassword";
import Hard from "./screens/Hard";
import Medium from "./screens/Medium";
import Simple from "./screens/Simple";
import WorkoutPlans from "./screens/WorkoutPlans";
import AboutUs from "./screens/AboutUs";
import Description from "./screens/Description";
import Exercises from "./screens/Exercises";
import SignIn from "./screens/SignIn";
import LogIn from "./screens/LogIn";
import Home from "./screens/Home";
import StartingPage from "./screens/StartingPage";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);
  const [fontsLoaded, error] = useFonts({
    "Jockey One_regular": require("./assets/fonts/Jockey_One_regular.ttf"),
    Fresca_regular: require("./assets/fonts/Fresca_regular.ttf"),
    Graduate_regular: require("./assets/fonts/Graduate_regular.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Contact"
              component={Contact}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ChangePassword"
              component={ChangePassword}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Hard"
              component={Hard}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Medium"
              component={Medium}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Simple"
              component={Simple}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="WorkoutPlans"
              component={WorkoutPlans}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="AboutUs"
              component={AboutUs}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Description"
              component={Description}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Exercises"
              component={Exercises}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignIn"
              component={SignIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LogIn"
              component={LogIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home"
              component={Home}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="StartingPage"
              component={StartingPage}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
